package edu.usfca.cs.cs245;

public interface Practice2Search {

	public String searchName(); // Return search type
	public int search(int [] arr, int target); // Function
}
